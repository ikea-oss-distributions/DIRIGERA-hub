#!/bin/sh -e

git clone https://github.com/google/googletest
