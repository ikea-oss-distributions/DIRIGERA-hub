export LVM_TEST_LOCKING=1
export LVM_TEST_LVMPOLLD=1
export LVM_TEST_LVMLOCKD=1
export LVM_TEST_LVMLOCKD_TEST=1
export LVM_TEST_DEVDIR=/dev

# FIXME:dct: add option to allow --test with sanlock
export LVM_TEST_LVMLOCKD_TEST_DLM=1
