#!/usr/bin/env perl

use 5.010_001; # Require Perl5 version 10.1 or newer
use strict;
use warnings;

say scalar localtime;  # now
