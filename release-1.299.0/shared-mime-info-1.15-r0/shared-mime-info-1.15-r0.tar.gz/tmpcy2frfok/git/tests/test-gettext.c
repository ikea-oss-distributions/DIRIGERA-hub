#include <stdio.h>

int main()
{
  printf(_("test of string\n"));
  return 0;
}
