## kmod - Linux kernel module handling

[![Coverity Scan Status](https://scan.coverity.com/projects/2096/badge.svg)](https://scan.coverity.com/projects/2096)

This is a ***mirror only***. Please see [README](../master/README) file for more information.
